function parsave(name, variable)

save(name,'variable');

end